<?php

$config = [
	//  translators: This is a brand name. Preferably to not be translated
	'name' => _x('Adobe Fonts', 'Extension Brand Name', 'blocksy-companion'),
	'description' => __('Connect your Adobe Fonts project and use the selected fonts throughout Blocksy and your favorite page builder.', 'blocksy-companion'),
	'pro' => true
];