<?php

$config = [
	'name' => __('Wishlist', 'blocksy-companion'),

	'selective_refresh' => [
		'wishlist_item_type'
	],

	'translation_keys' => [
		['key' => 'wishlist_label']
	]
];

