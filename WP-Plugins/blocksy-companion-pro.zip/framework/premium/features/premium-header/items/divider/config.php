<?php

$config = [
	'name' => __('Divider', 'blocksy-companion'),
	'clone' => 7,
];
