<?php

$class = 'ct-header-divider';


?>


<div
	class="<?php echo esc_attr($class) ?>"
	<?php echo blocksy_attr_to_html($attr) ?>>
</div>