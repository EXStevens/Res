<?php

$options = blocksy_get_options(
	get_template_directory() . '/inc/panel-builder/footer/menu/options.php',
	[
		'location' => 'Footer Menu 2'
	],
	false
);

