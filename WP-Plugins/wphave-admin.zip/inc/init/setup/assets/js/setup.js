﻿( function($) {
  	'use strict';	
	
	// Show / Hide Purchase Code Input Value
	/*****************************************************************/
	
	var codeBtn = $('#purchase_code_show');
	
	$(document).ready(function() {
		if( codeBtn.hasClass('isVisible') ) {
			codeBtn.find('.dashicons-visibility').hide();
			codeBtn.find('.dashicons-hidden').show();
		} else {
			codeBtn.find('.dashicons-visibility').show();
			codeBtn.find('.dashicons-hidden').hide();
		}
	});
	
	codeBtn.on("click", function() {
		
		$(this).toggleClass('isVisible');		
		
    	if( $(this).hasClass('isVisible') ) {
			codeBtn.find('.dashicons-visibility').hide();
			codeBtn.find('.dashicons-hidden').show();
  			return $('#purchase_code').attr('type', 'text');
    	} else {
			codeBtn.find('.dashicons-visibility').show();
			codeBtn.find('.dashicons-hidden').hide();
		}
    	$('#purchase_code').attr('type', 'password');
	});
	
})(jQuery);