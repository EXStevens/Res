<?php

$options = [
	'has_cart_coupons' => [
		'label' => __('Coupon Form', 'blocksy-companion' ),
		'type' => 'ct-switch',
		'value' => 'yes',
		'sync' => blocksy_sync_whole_page([
			'loader_selector' => '.ct-cart-form .woocommerce-cart-form'
		]),
	],

	'has_cart_auto_update' => [
		'label' => __( 'Quantity Auto Update', 'blocksy-companion' ),
		'type' => 'ct-switch',
		'value' => 'no',
		'divider' => 'top',
		'sync' => blocksy_sync_whole_page([
			'loader_selector' => '.ct-cart-form .woocommerce-cart-form'
		]),
	],

	'cart_page_image_ratio' => [
		'label' => __('Image Ratio', 'blocksy-companion'),
		'type' => 'ct-ratio',
		'view' => 'inline',
		'value' => '1/1',
		'divider' => 'top:full',
		'sync' => blocksy_sync_whole_page([
			'loader_selector' => '.ct-cart-form .woocommerce-cart-form'
		]),
	],

	'cart_page_image_size' => [
		'label' => __('Image Size', 'blocksy-companion'),
		'type' => 'ct-select',
		'value' => 'woocommerce_thumbnail',
		'view' => 'text',
		'design' => 'inline',
		'divider' => 'top',
		'choices' => blocksy_ordered_keys(
			blocksy_get_all_image_sizes()
		),
		'sync' => blocksy_sync_whole_page([
			'loader_selector' => '.ct-cart-form .woocommerce-cart-form'
		]),
	],
];