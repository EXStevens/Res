<?php

$config = blc_exts_get_preliminary_config('color-mode-switch');

