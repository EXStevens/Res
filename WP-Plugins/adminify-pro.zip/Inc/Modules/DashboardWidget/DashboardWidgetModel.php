<?php

namespace WPAdminify\Inc\Modules\DashboardWidget;

use WPAdminify\Inc\Base_Model;

abstract class DashboardWidgetModel extends Base_Model
{
    protected $prefix = '_wpadminify_dasboard_widgets';
}
